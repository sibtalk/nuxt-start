export default defineAppConfig({
  ui: {
    primary: 'ip55',
    gray: 'zinc',
  }
})