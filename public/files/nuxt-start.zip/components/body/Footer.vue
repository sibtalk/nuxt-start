<template>
  <div class="footer">
    <UContainer class="py-8 text-center">
      Вопросы и отзывы оставляйте в <a href="https://vk.com/topic-221899458_51474213" class="text-underline" target="_blank">группе ВК</a>
    </UContainer>
  </div>
</template>
